insert into employees values(10001,'Ramesh', 'Fadatare', 'ramesh@gmail.com');

insert into employees values(10002,'Jit', 'Jadhav', 'jadhav@gmail.com');